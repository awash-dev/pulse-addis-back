const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const { query } = require('./configure/dbClient');

function quoteIdent(name) {
  return '"' + name.replace(/"/g, '""') + '"';
}

async function seedData() {
  const exportDir = path.join(__dirname, 'exports');
  const allDataPath = path.join(exportDir, 'all-data.json');
  
  if (!fs.existsSync(allDataPath)) {
    console.log("No all-data.json found. Please run npm run export-data first.");
    return;
  }
  
  const allData = JSON.parse(fs.readFileSync(allDataPath, 'utf8'));
  
  // Ordered tables to satisfy most foreign key constraints
  const orderedTables = [
    'User',
    'Category',
    'Subcategory',
    'Brand',
    'Tag',
    'Size',
    'Color',
    'Coupon',
    'FQA',
    'Package',
    'BlogCategory',
    'BlogSubCategory',
    'HealthAdvice',
    'Promotion',
    'AdHome',
    'SpecialAd',
    'BannerAd',
    'Store',
    'Product',
    'ProductColor',
    'Order',
    'OrderItem',
    'Review',
    'Cart',
    '_Wishlist',     // from schema.prisma (implicitly maps to Wishlist)
    'Activity',
    'Report',
    'Notification',
    'Conversation',
    '_UserConversations', // implicitly maps to ConversationUsers
    'Message',
    'Blog',
    'DeliveryAssignment'
  ];

  // Also include any tables in allData that aren't specifically ordered above
  // Mapping from export filenames/keys to actual database table names
  const tableNameMap = {
    '_Wishlist': 'Wishlist',
    '_UserConversations': 'ConversationUsers'
  };

  const remainingTables = Object.keys(allData).filter(t => !orderedTables.includes(t));
  const tablesToSeed = [...orderedTables, ...remainingTables];

  console.log("Starting data seed...");

  for (let table of tablesToSeed) {
    const rows = allData[table];
    if (!rows || !rows.length) {
      continue;
    }

    // Map to actual DB table name if necessary
    const dbTableName = tableNameMap[table] || table;
    
    console.log(`Seeding table: ${table} (as ${dbTableName}) (${rows.length} rows)`);
    
    // Get valid columns and their data types for the table
    const tableInfo = await query(`SELECT column_name, data_type FROM information_schema.columns WHERE table_name = $1 AND table_schema = 'public'`, [dbTableName.replace(/"/g, '')]);
    const columnTypes = tableInfo.rows.reduce((acc, r) => {
      acc[r.column_name] = r.data_type;
      return acc;
    }, {});
    const validColumns = Object.keys(columnTypes);

    if (validColumns.length === 0) {
      console.log(`  [!] Skipping ${table} (table ${dbTableName} not found in public schema)`);
      continue;
    }

    const columns = Object.keys(rows[0]).filter(col => validColumns.includes(col));
    const columnsSql = columns.map(quoteIdent).join(', ');
    
    let successCount = 0;
    
    for (const row of rows) {
      const uuidMap = {
        'default-color-id': '00000000-0000-4000-8000-000000000001',
        'p-color-main': '00000000-0000-4000-8000-000000000002'
      };
      
      const values = columns.map(col => {
        let val = row[col];
        if (uuidMap[val]) val = uuidMap[val];
        
        const type = columnTypes[col];
        if (val !== null && typeof val === 'object') {
          if (type === 'json' || type === 'jsonb') {
            return JSON.stringify(val);
          }
          // Don't stringify JS arrays if the target is a Postgres ARRAY
          if (Array.isArray(val) && type === 'ARRAY') {
            return val;
          }
          // Other objects might need stringification if target is json/jsonb, but we checked type above.
          // Fallback to stringify if it's an object and not an array, just in case.
          return Array.isArray(val) ? val : JSON.stringify(val);
        }
        return val;
      });
      const placeholders = columns.map((_, i) => `$${i + 1}`).join(', ');
      
      // Attempt to insert and ignore if key already exists
      const sql = `INSERT INTO ${quoteIdent(dbTableName)} (${columnsSql}) VALUES (${placeholders}) ON CONFLICT DO NOTHING`;
      
      try {
        const res = await query(sql, values);
        if (res.rowCount > 0) {
          successCount++;
        }
      } catch (e) {
        console.error(`  [X] Error inserting row into ${dbTableName}:`, e.message);
      }
    }
    
    console.log(`  -> Inserted ${successCount} new rows. (${rows.length - successCount} ignored due to conflict/error)`);
  }
  
  console.log("Seeding complete!");
}

seedData().catch(e => {
  console.error("Seed process failed:", e);
  process.exit(1);
});
