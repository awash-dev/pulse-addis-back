const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const { query } = require('./configure/dbClient');

function quoteIdent(name) {
  return '"' + name.replace(/"/g, '""') + '"';
}

function sanitizeValue(value) {
  if (value === null || value === undefined) {
    return value;
  }
  if (Buffer.isBuffer(value)) {
    return value.toString('utf8');
  }
  if (typeof value === 'bigint') {
    return value.toString();
  }
  if (value instanceof Date) {
    return value.toISOString();
  }
  if (typeof value === 'object') {
    try {
      return JSON.parse(JSON.stringify(value));
    } catch (error) {
      return String(value);
    }
  }
  return value;
}

async function getPublicTables() {
  const result = await query(
    `SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = 'public' ORDER BY tablename`
  );
  return result.rows.map((row) => row.tablename);
}

const exportDir = path.join(__dirname, 'exports');

function ensureExportDirectory() {
  if (!fs.existsSync(exportDir)) {
    fs.mkdirSync(exportDir, { recursive: true });
  }
}

async function exportAllData() {
  console.log('Fetching list of public tables...');
  const tables = await getPublicTables();

  if (!tables.length) {
    console.log('No public tables found in the database.');
    return;
  }

  ensureExportDirectory();

  const allData = {};

  for (const table of tables) {
    const quotedTable = quoteIdent(table);
    console.log(`Querying table: ${table}`);
    const result = await query(`SELECT * FROM ${quotedTable}`);

    const rows = result.rows.map((row) => {
      const sanitizedRow = {};
      for (const [key, value] of Object.entries(row)) {
        sanitizedRow[key] = sanitizeValue(value);
      }
      return sanitizedRow;
    });

    allData[table] = rows;
    const tableFile = path.join(exportDir, `${table}.json`);
    fs.writeFileSync(tableFile, JSON.stringify(rows, null, 2), 'utf8');
    console.log(`  → ${result.rows.length} rows exported to ${tableFile}`);
  }

  const outputPath = path.join(exportDir, 'all-data.json');
  fs.writeFileSync(outputPath, JSON.stringify(allData, null, 2), 'utf8');
  console.log(`All table exports combined into ${outputPath}`);
}

exportAllData().catch((error) => {
  console.error('Export failed:', error);
  process.exit(1);
});
