const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const { query } = require('./configure/dbClient');
const bcrypt = require('bcryptjs');

async function exportUsers() {
  try {
    const newPassword = 'Pulse@Admin123';
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    console.log('Updating all user passwords...');

    // Update all user passwords
    await query('UPDATE "User" SET password = $1', [hashedPassword]);

    console.log('Passwords updated. Fetching user data...');

    const result = await query('SELECT firstname, lastname, email FROM "User" ORDER BY "createdAt" DESC');

    if (result.rows.length === 0) {
      console.log('No users found.');
      return;
    }

    console.log(`Found ${result.rows.length} users.`);

    // Format the data as text with name, email, password
    let output = 'USER DATA EXPORT\n';
    output += '=' .repeat(50) + '\n\n';

    result.rows.forEach((user, index) => {
      output += `User ${index + 1}:\n`;
      output += `- Name: ${user.firstname} ${user.lastname}\n`;
      output += `- Email: ${user.email}\n`;
      output += `- Password: ${newPassword}\n`;
      output += '\n' + '-'.repeat(30) + '\n\n';
    });

    // Write to file
    const filePath = path.join(__dirname, 'user.txt');
    fs.writeFileSync(filePath, output, 'utf8');

    console.log(`User data exported to ${filePath}`);

  } catch (error) {
    console.error('Error:', error);
  } finally {
    process.exit();
  }
}

// Run the export
exportUsers();